package com.Trainee.TraineeMgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Trainee.TraineeMgmt.model.Login;
import com.Trainee.TraineeMgmt.model.Trainee;

public interface TraineeRepository extends JpaRepository<Trainee, Integer> {

	void saveAndFlush(Login log);



}

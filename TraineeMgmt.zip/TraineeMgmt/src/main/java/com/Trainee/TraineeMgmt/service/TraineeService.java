package com.Trainee.TraineeMgmt.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Trainee.TraineeMgmt.dao.LoginRepository;
import com.Trainee.TraineeMgmt.dao.TraineeRepository;
import com.Trainee.TraineeMgmt.model.Login;
import com.Trainee.TraineeMgmt.model.Trainee;


@Service
public class TraineeService {
	
    @Autowired
	TraineeRepository repository;
    
    @Autowired
    LoginRepository logrepository;
    
    @Transactional
    public void doLogin(Login log) {
    	repository.saveAndFlush(log);
    }
    
    @Transactional
	public void insertTrainee(Trainee tr) {
    	repository.saveAndFlush(tr);
    }
	public Trainee removeTrainee(int traineeId) {
		Optional<Trainee> opt=repository.findById(traineeId);
		if(opt.isPresent())
		 {
			Trainee tr=opt.get();
			repository.delete(tr);
			
		 } 
		return null;
	}
	
	public Trainee findTrainee(int traineeId){
		Optional<Trainee> opt=repository.findById(traineeId);
		if(opt.isPresent()) 
			return opt.get();	
		return null;
	}
	
	public List<Trainee> getTrainees(){
		return repository.findAll();
		
	}
	 public Trainee updatePartially(Trainee tr, int traineeId) {
	        // TODO Auto-generated method stub
	        Optional<Trainee> opt=repository.findById(traineeId);
			if(opt.isPresent())
			{
			   tr.setTraineeDomain(tr.getTraineeDomain());
			   return repository.saveAndFlush(tr);
			}
	       
			return null;
	    }

}

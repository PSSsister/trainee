package com.Trainee.TraineeMgmt.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.Trainee.TraineeMgmt.model.Trainee;

import com.Trainee.TraineeMgmt.service.TraineeService;





@Controller
public class TraineeController {
    @Autowired
	TraineeService service;
    

    @RequestMapping("/home")
	public String home() {
		System.out.println("inside home");
		return "home";
	}
    @RequestMapping("/login")
	public String checkCredentials(String userName,String pass)
	{
		if(userName.equals("admin")&& pass.equalsIgnoreCase("admin"))
		{
			return "home";
		}
		else
		{
			return "Please check the enter credentials";
		}
	
	}
	
    @RequestMapping("/login")
   	public String login() {
   		System.out.println("inside login");
   		return "login";
   	}
    @RequestMapping(value="/addTrainee", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
	  
	  //ModelAndView mav = new ModelAndView("addEmp");
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addTrainee"); mav.addObject("trainee", new Trainee()); 
		  return mav; 
	  }
    
	@RequestMapping(value="/addTrainee", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("trainee") Trainee tr) {
		
		service.insertTrainee(tr);
		ModelAndView mav = new ModelAndView("addEmp");
		String message = "Employee Added Successfully ";
		mav.addObject("successMessage", message);
		return mav;
	}
	
	@RequestMapping(value="/deleteTrainee", method=RequestMethod.GET)
	public ModelAndView loadTraineeById() {			
		ModelAndView mav = new ModelAndView("deleteTrainee");	
		mav.addObject("trainee", new Trainee()); 
		return mav;
	}
	
	@RequestMapping(value="/deleteTrainee", method=RequestMethod.POST)
	public ModelAndView deleteEmployeeId(@RequestParam Integer traineeId)
	{
		Trainee trainee = service.findTrainee(traineeId);
		System.out.println("found = "+trainee);
		ModelAndView mav = new ModelAndView("deleteTrainee");
		
	        if (trainee == null) {
	        	mav.addObject("errorMessage","Employee details not found for the given trainee id");
	    		
	        }
	        
		service.removeTrainee(traineeId);
		System.out.println("delete operation");
	    return mav;
	
		
	}
	 /* @RequestMapping(value="/login", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
	  
	  //ModelAndView mav = new ModelAndView("addEmp");
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("login");
		  mav.addObject("login", new Login()); 
		  return mav; 
	  }
	  @RequestMapping(value="/login", method=RequestMethod.POST)
		public ModelAndView addEmployee( Login log) {
			
			service.doLogin(log);
			ModelAndView mav = new ModelAndView("login");
			String message = "Trainee login Successfully";
			mav.addObject("successMessage", message);
			return mav;
		}*/
    

}
